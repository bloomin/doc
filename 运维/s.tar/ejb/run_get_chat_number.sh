#!/bin/bash
cd `dirname $0`
CHAT_TIME=`date +"%Y-%m-%d %H:%M:%S"`
echo ${CHAT_TIME} >> /data/sh/ejb/get_chat_number.log
for SERVER in `awk -F[:,\(\)\"] '/CHAT_DOMAIN_LIST/{print $9,$12,$15}' /data/web/minggame/config/config.inc.php`                 
do
ssh -o StrictHostKeyChecking=no ${SERVER} "/data/sh/ejb/get_chat_number.sh" >> /data/sh/ejb/get_chat_number.log
done
