#!/bin/bash
CHAT_PORT=`sed -n "110p" /data/conf/ejabberd/ejabberd.cfg |awk -F[\{,] '{print $2}'`
CHAT_IP=`ifconfig eth0 | grep "inet addr" | awk '{print $2;}' | cut -f2 -d":"`
CHAT_NO=`netstat -n |grep ESTABLISHED |awk '{print $4}' |grep ${CHAT_IP} | grep ${CHAT_PORT} |wc -l`
echo ${CHAT_IP},${CHAT_NO}
