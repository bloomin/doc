#!/bin/bash
#restart ejabberd for slave
echo "执行完脚本后显示三个 请复制此行执行 这里需要手动复制去执行拷主机的聊天数据，最后启动ejabberd"
IPMASTER=`awk -F[:\/] '/persistent=1/{print $4}' /etc/php.ini`
IPSLAVE=`ifconfig | grep "192.168" |awk '{print $2}'|cut -f 2 -d ":"`
echo "停止跟ejabberd相关的进程"
pkill -9 epmd

pkill -9 beam.smp
echo "删除数据"
cd /usr/local/ejabberd/var/lib/ejabberd/

/bin/rm -rf *

/bin/rm -f .erlang.cookie

/bin/rm -f /root/.erlang.cookie

echo "重新复制cookie"
scp -o StrictHostKeyChecking=no ${IPMASTER}:/usr/local/ejabberd/var/lib/ejabberd/.erlang.cookie /usr/local/ejabberd/var/lib/ejabberd/

scp -o StrictHostKeyChecking=no ${IPMASTER}:/usr/local/ejabberd/var/lib/ejabberd/.erlang.cookie /root/

#echo "请复制此行执行  mnesia:change_table_copy_type(schema, node(), disc_copies)."

#echo "请复制此行执行  q()."

#echo "请复制此行执行  /root/ejabberdctl start"
erl -name ejabberd@${IPSLAVE} -pa /usr/local/ejabberd/lib/ejabberd/ebin -mnesia dir \"/usr/local/ejabberd/var/lib/ejabberd/\"  -mnesia extra_db_nodes "['ejabberd@${IPMASTER}']" -s mnesia -s ming_slave_init start -s init stop -noinput -noshell

sleep 2
/root/ejabberdctl start
