#!/bin/bash

/root/ejabberdctl stop
sleep 2

FF=`ps awx | grep beam | grep -v grep | awk '{print $1;}'`
if [ -n "${FF}" ]; then
        for HH in ${FF} 
        do
                echo "kill1  ${HH}"
                kill ${HH}
        done
        sleep 3

        FF2=`ps awx | grep beam | grep -v grep | awk '{print $1;}'`
        if [ -n "${FF2}" ]; then
                for HH in ${FF2} 
                do
                        echo "kill2  ${HH}"
                        kill ${HH}
                done
                sleep 3
        fi
fi

/root/ejabberdctl start
sleep 10
FF=`ps awx | grep beam | grep -v grep | awk '{print $1;}'`
if [ -z "${FF}" ]; then
	/root/ejabberdctl start
fi
/usr/bin/php /data/web/minggame/www/update/ming_chat_init_connection.php
