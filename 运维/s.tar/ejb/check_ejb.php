#!/usr/bin/php
<?php

$cc = exec("top -b -n1 | grep beam\.smp | grep -v grep | awk '{print $6;}'", $aa, $bb);

#print_r(array($aa, $bb, $cc));

define('MAX_MEMORY_USE', 4);

if (strlen($cc) > 10 )
	die("error");
else if (!empty($cc))
{
        if (substr($cc, -1 ) === 'g')
        {
                $size = floatval(substr($cc, 0, -1));
                if ($size > MAX_MEMORY_USE)
                        die( "alert" );
        }
}

echo "safe";


