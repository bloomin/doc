#!/bin/bash
CHECK_TIME=`date +"%Y-%m-%d %H:%M:%S"`
FILTER="==============="
echo ${FILTER}${CHECK_TIME}${FILTER} >> /data/logs/timewait.log
netstat -n | awk '/^tcp/ {++S[$NF]} END {for(a in S) print a, S[a]}' >> /data/logs/timewait.log
