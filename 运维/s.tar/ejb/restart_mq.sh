#!/bin/bash
export PATH=$PATH:/usr/local/bin/
set -x
/root/mq_stop

if cd /data/memcacheq/
then
rm -rf *
fi
sleep 30
/root/mq_start
sleep 10
mqid=`netstat -tlnp | grep 22201 |awk -F::: '{print $2}' |cut -f1 -d" "`

while [ "${mqid}" != 22201 ]
do
mqid=`netstat -tlnp | grep 22201 |awk -F::: '{print $2}' |cut -f1 -d" "`
if cd /data/memcacheq/
then
rm -rf *
fi
sleep 30
/root/mq_start
sleep 10
mqid=`netstat -tlnp | grep 22201 |awk -F::: '{print $2}' |cut -f1 -d" "`
done
/usr/bin/php /data/web/minggame/www/update/sync_user_to_server.php "type=month"
/usr/bin/php /data/web/minggame/www/update/sync_user_to_server.php "type=chat"
/root/fastcgi_restart
