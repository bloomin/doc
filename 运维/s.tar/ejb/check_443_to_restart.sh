#!/bin/bash
export PATH=$PATH:/usr/local/bin/
if ps awx | grep restart_ejabberd_for_master.sh |grep -v grep
then
exit 1
else
ejport=`netstat -tlnp | grep beam.smp|grep 443 |awk -F: '{print $2}'|cut -f1 -d" "`

restartejabberdall()
{
sh /root/restart_ejabberd_for_master.sh y
}
while [ "${ejport}" != 443 ]
do
        if netstat -tlnp | grep 443
        then
        echo "OK"
        exit
        else
        date
        restartejabberdall
        fi
done
fi
