#!/bin/bash
export PATH=$PATH:/usr/local/bin/
set -x
if ps awx | grep restart_mq.sh |grep -v grep
then
exit 1
else
mqport=`netstat -tlnp | grep 22201 |awk -F::: '{print $2}' |cut -f1 -d" "`

restartejabberdall()
{
bash /data/sh/ejb/restart_mq.sh
}
while [ "${mqport}" != 22201 ]
do
        if netstat -tlnp | grep 22201
        then
        echo "OK"
        exit
        else
        date
        restartejabberdall
        fi
done
fi
