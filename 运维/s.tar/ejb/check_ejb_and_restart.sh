#!/bin/bash
# Author hlh
export PATH=$PATH:/usr/local/bin/
RESTAERT_DATE=`date "+%Y-%m-%d-%H-%M"`
DOMAIN=`php /data/web/minggame/config/show.php type=domain`
GAME_HOST=`awk -F[" "_] '/PS/ {print $5}' /root/.bashrc`
if ps awx | grep restart_ejabberd_for_master.sh |grep -v grep
then
exit 1
fi
if ps awx | grep restart_ejabberd_for_slave.sh |grep -v grep
then
exit 1
fi
if  /root/ejabberdctl registered_users ${DOMAIN}
then
exit 1

	elif [ "${GAME_HOST}" = "A" ]
	then
	/bin/bash /data/sh/ejb/restart_ejabberd_for_master.sh y
	echo "${RESTAERT_DATE} restart master ejb success!" >> /data/web/minggame/log/restart_ejabberd_for_master.log
		for SERVER in `awk -F[:,\(\)\"] '/CHAT_DOMAIN_LIST/{print $9,$12,$15}' 	/data/web/minggame/config/config.inc.php`                 
		do
		ssh -o StrictHostKeyChecking=no ${SERVER} "/bin/bash /data/sh/ejb/restart_ejabberd_for_slave.sh" 
		echo "${RESTAERT_DATE} restart slave ejb success!" >> /data/web/minggame/log/restart_ejabberd_for_slave.log
		done
	else
	/bin/bash /data/sh/ejb/restart_ejabberd_for_slave.sh
fi
