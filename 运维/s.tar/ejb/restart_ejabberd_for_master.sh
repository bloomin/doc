#!/bin/bash
#filename:restart_ejabberd
if [ "$1" = "" ] ; then
	echo "请在脚本后面输入Y或N，大小写均可。"
	exit 1
fi

restartejabberdall()
{
/root/mq_stop
rm -rf /data/memcacheq/*

echo "停止跟ejabberd相关的进程"
pkill epmd
pkill beam.smp

echo "删除ejabberd cookie数据"
if cd /usr/local/ejabberd/var/lib/ejabberd/
then
rm -rf *
rm -f .erlang.cookie
rm -f /root/.erlang.cookie
fi

echo "开启聊天，注册帐号"
/root/mq_start
/root/ejabberdctl start
sleep 10
/data/sh/init/mcsd/register_new_chat_admin_account.sh
sleep 5
echo "同步聊天帐号"
php /data/web/minggame/www/update/sync_user_to_server.php "start=1&end=50000"
sleep 1
php /data/web/minggame/www/update/sync_user_to_server.php "start=50000&end=100000"
sleep 1
php /data/web/minggame/www/update/sync_user_to_server.php "start=100000&end=150000"
sleep 1
php /data/web/minggame/www/update/sync_user_to_server.php "start=150000&end=200000"
sleep 1
php /data/web/minggame/www/update/sync_user_to_server.php "start=200000&end=300000"
}
restartejabberd()
{
/root/mq_stop
rm -rf /data/memcacheq/*

echo "停止跟ejabberd相关的进程"
pkill epmd
pkill beam.smp

echo "删除ejabberd数据"
cd /usr/local/ejabberd/var/lib/ejabberd/
rm -rf *

echo "开启聊天，注册帐号"
/root/mq_start
/root/ejabberdctl start
sleep 10
/data/sh/init/mcsd/register_new_chat_admin_account.sh
sleep 5
echo "同步聊天帐号"
php /data/web/minggame/www/update/sync_user_to_server.php "start=1&end=50000"
sleep 1
php /data/web/minggame/www/update/sync_user_to_server.php "start=50000&end=100000"
sleep 1
php /data/web/minggame/www/update/sync_user_to_server.php "start=100000&end=150000"
sleep 1
php /data/web/minggame/www/update/sync_user_to_server.php "start=150000&end=200000"
sleep 1
php /data/web/minggame/www/update/sync_user_to_server.php "start=200000&end=300000"
}
restarmq()
{
/root/mq_stop

cd /data/memcacheq/

rm -rf *

/root/mq_start

php /data/web/minggame/www/update/sync_user_to_server.php "start=1&end=50000"
sleep 1
php /data/web/minggame/www/update/sync_user_to_server.php "start=50000&end=100000"
sleep 1
php /data/web/minggame/www/update/sync_user_to_server.php "start=100000&end=150000"
sleep 1
php /data/web/minggame/www/update/sync_user_to_server.php "start=150000&end=200000"
sleep 1
php /data/web/minggame/www/update/sync_user_to_server.php "start=200000&end=300000"

}
SERVER_NAME=`awk -F\" '/\"WEB_DOMAIN/{print $4}' /data/web/minggame/config/config.inc.php`
echo "选择Y或y则重新配置ejabberd。选择N或n则只是重启ejabberd,先择m或M则重启mq"
case $1 in 
        Y|y)
        echo "reconfiguration ejabberd now!"
        restartejabberdall
        ;;
        N|n)
        echo "only restart ejabberd now!"
        restartejabberd 
        ;;
	m|M)
	restarmq
	;;
esac

