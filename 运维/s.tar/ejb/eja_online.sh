#!/bin/bash
/root/ejabberdctl connected_users_number
