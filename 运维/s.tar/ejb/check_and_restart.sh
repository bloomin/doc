#!/bin/bash

FF=`dirname ${0}`
cd ${FF}/

SIZE=`top -b -n1 | grep beam\.smp | grep -v grep | awk '{print $6;}'`
echo "[`date +"%Y-%m-%d %H:%M:%S"`] Size: ${SIZE} " >> check_and_restart.log

DD=`/usr/bin/php check_ejb.php`
if [ "${DD}" = "alert" ]; then
	sleep 2
	echo "[`date +"%Y-%m-%d %H:%M:%S"`] alert. restart ejabberd." >> check_and_restart.log
	./restart_ejb.sh >> check_and_restart.log
fi

