#!/bin/bash


cd /data/web/minggame/config
PASS=`/usr/bin/php show.php type=chat`
HOST=`/usr/bin/php show.php type=domain`

if [ "${HOST}" = "" ]; then
        echo "Domain Error!"
        exit 1
fi


/root/ejabberdctl register admin ${HOST} ${PASS}
/root/ejabberdctl register system ${HOST} ${PASS}

for HH in `seq 0 100`
do
        /root/ejabberdctl register system_${HH} ${HOST} ${PASS}
done


