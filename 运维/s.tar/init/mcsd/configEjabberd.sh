#!/bin/bash

cd /data/web/minggame/config
DOMAIN=`php show.php type=domain`

if [ "${DOMAIN}" = "" ]; then
        echo "Domain Error!"
        exit 1
fi

if [ ! -e "/data/conf/ejabberd/ejabberd.cfg.tpl" ]; then

	echo "Error! ejabberd.cfg.tpl file not exist."
	exit 1
fi

if [ ! -e "/data/conf/ejabberd/ejabberdctl.cfg.tpl" ]; then

	echo "Error! ejabberdctl.cfg.tpl file not exist."
	exit 1
fi

LIP=`ifconfig eth1 | grep "inet addr" | awk '{print $2;}' | cut -f2 -d":"`

if [ "${LIP}" = "" ]; then
        echo "IP address Error!"
        exit 1
fi

if [ ! -d "/usr/local/ejabberd/etc" ]; then
	echo "ejabberd not install"
	exit 1
fi

echo "Setting /data/conf/ejabberd/ejabberd.cfg"
echo "Setting /data/conf/ejabberd/ejabberdctl.cfg"

cd /usr/local/ejabberd/etc/
LINK_DIR_NAME="ejabberd"
if [ ! -L ${LINK_DIR_NAME} ]
then
        /bin/rm -rf ${LINK_DIR_NAME}
        ln -s /data/conf/ejabberd ${LINK_DIR_NAME}
fi


/bin/cp /data/conf/ejabberd/ejabberd.cfg.tpl /data/conf/ejabberd/ejabberd.cfg
/bin/cp /data/conf/ejabberd/ejabberdctl.cfg.tpl /data/conf/ejabberd/ejabberdctl.cfg

sed -i "s@##SERVERNAME##@${DOMAIN}@g" /data/conf/ejabberd/ejabberd.cfg
sed -i "s#INETIP#${LIP}#" /data/conf/ejabberd/ejabberdctl.cfg

if [ "$1" = "master" ]; then
    sed -i "s@##CHATPORT##@443@g" /data/conf/ejabberd/ejabberd.cfg
else 
    sed -i "s@##CHATPORT##@80@g" /data/conf/ejabberd/ejabberd.cfg
fi
	
echo '/usr/local/ejabberd/sbin/ejabberdctl connected-users' > /root/eu
echo '/usr/local/ejabberd/sbin/ejabberdctl connected-users-number' >> /root/eu
chmod 700 /root/eu

mkdir -p /data/muclogs/

echo "OK."
echo "You can run /root/ejabberdctl start"
echo ""


