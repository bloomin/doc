#!/bin/bash

# eth0 网卡的IP地址，一般就是电信IP地址
LIP=`ifconfig eth0 | grep "inet addr" | awk '{print $2;}' | cut -f2 -d":"`

if [ "${LIP}" = "" ]; then
	echo "IP address Error!"
	exit 1
fi

LIP_TAIL=`echo ${LIP} | cut -f3 -d"."`.`echo ${LIP} | cut -f4 -d"."`

echo "Current Server IP is : "${LIP}
echo "Setting ${LIP_TAIL}.ming.cn  hosts..."

/bin/cp /data/conf/nginx/nginx.conf.tpl /data/conf/nginx/nginx.conf
sed -i "s@##MINGCNSERVER##@${LIP_TAIL}.ming.cn@g" /data/conf/nginx/nginx.conf

cd /data/web/minggame/config
DOMAIN=`php show.php type=domain`

if [ "${DOMAIN}" = "" ]; then
        echo "Domain Error!"
        exit 1
fi

echo "Setting /data/conf/nginx/vhost/mingchao.conf"

if [ "$1" = "master" ]; then
	/bin/cp /data/conf/nginx/vhost/mingchao.conf.tpl.master  /data/conf/nginx/vhost/mingchao.conf
else
	/bin/cp /data/conf/nginx/vhost/mingchao.conf.tpl.slaver  /data/conf/nginx/vhost/mingchao.conf
	sed -i "/listen/ s@80@82@" /data/conf/nginx/nginx.conf
fi

# 配置明朝的主机，根据 config.php 中已经设置好的域名来生成nginx配置文件
sed -i "s@##SERVERNAME##@${DOMAIN}@g" /data/conf/nginx/vhost/mingchao.conf

echo "OK."
echo "You can run /root/nginx_start now."
echo ""


