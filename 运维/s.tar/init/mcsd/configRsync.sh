#!/bin/bash

# eth0 网卡的IP地址，一般就是电信IP地址
LIP=`ifconfig eth0 | grep "inet addr" | awk '{print $2;}' | cut -f2 -d":"`

if [ "${LIP}" = "" ]; then
	echo "IP address Error!"
	exit 1
fi

echo "Current Server IP is : "${LIP}
echo "Setting rsyncd.motd file ..."

MOTDFILE="/etc/rsyncd.motd"
echo "Welcome to use the rsync services!" > ${MOTDFILE}
echo "Current Server IP: ${LIP}" >> ${MOTDFILE}
echo "" >> ${MOTDFILE}


echo "Setting rsyncd.conf file ..."

cd /data/web/minggame/config
DBNAME=`php show.php type=dbname`

if [ "${DBNAME}" = "" ]; then
        echo "DB name Error!"
        exit 1
else
        if [ ! -d "/data/database/mysql/${DBNAME}" ]; then
                echo "DB not create !"
                exit 1
        fi
fi


/bin/cp /data/conf/rsync/rsyncd.conf.tpl /etc/rsyncd.conf
sed -i "s@##DBNAME##@${DBNAME}@g" /etc/rsyncd.conf

echo "OK."  
echo "You can start:  /usr/local/bin/rsync --daemon"
echo ""


