#脚本目录
/data/sh
#crontab设置
*/30 * * * *  /bin/bash  /data/sh/clear_disk/bin/clear_disk.sh /data/sh/clear_disk/log/crontab/log 2>&1 &
#脚本说明
通用清理脚本，根据定义的空间阈值和清理的动作执行
请保持bin,conf,log下的目录结构
配置文件在conf下，默认阈值为85,默认清理动作为删除/data/backup/special_temp.log
#作者
ZCola
