#!/bin/sh
# ...print the ctc and cnc ip online
#made by longweijay
PATH=/usr/local/bin:/bin:/usr/bin:/usr/local/mysql/bin:/usr/local/sbin:/usr/sbin:/sbin
CTCIP=`ifconfig em1 | grep "inet addr" | awk '{print $2;}' | cut -f2 -d":"`
CNCIP=`ifconfig em1:1 | grep "inet addr" | awk '{print $2;}' | cut -f2 -d":"`
PORTRANG=`seq -f '%02g' 9999 9999`
netstat -ant > /data/logs/netstat.log

FUNCTION_ONLINE() {
IP="$1"
PORT="$2"
#echo ${ip}_${PORT}
ONLINE=`cat /data/logs/netstat.log |grep $IP:$PORT|grep -v 0.0.0.0|grep ESTABLISHED |wc -l`
}

DX_ONLINE() {
for port in ${PORTRANG}
do
FUNCTION_ONLINE ${CTCIP} ${port}
DXTOTEL=$(($DXTOTEL+$ONLINE))
done
}


WT_ONLINE() {
for port in ${PORTRANG}
do
FUNCTION_ONLINE ${CNCIP} ${port}
WTTOTEL=$(($WTTOTEL+$ONLINE))
done
#echo "WT_ONLINE"
#echo "${WTTOTEL}"
}

ONLINE_ALL() {
DX_ONLINE
WT_ONLINE
ONLINE_ALL=`expr ${WTTOTEL} + ${DXTOTEL}`
echo "ONLINE_ALL" && echo ${ONLINE_ALL}
echo "ONLINE_DX" && echo ${DXTOTEL}
echo "ONLINE_WT" && echo ${WTTOTEL}
}

RESULT=`ONLINE_ALL`
#注意这个地方 有换行的要赋值给变量 需要echo的时候要加双引号
echo "${RESULT}" > /tmp/online
