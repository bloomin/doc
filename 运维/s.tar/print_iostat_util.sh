#!/bin/sh
io=`iostat -x -t 1 5 |grep  "sda\>"|awk '{sum+=$12}END{print sum/NR}'`
echo $io >/tmp/iostat
