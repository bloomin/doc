#!/bin/bash
#Author hlh
UPDATE_DATE=`date +%Y%m%d`
GAMEFILE=$1
SQLFILE=$2
GAME_HOST=`awk -F[" "_] '/PS/ {print $5}' /root/.bashrc`
#1先T人.一般T两次比较保险
/bin/bash /data/sh/update/mcsd/stop_or_start_programme.sh stop
/bin/bash /data/sh/update/mcsd/stop_or_start_programme.sh stop

#2先把代理设置的循环消息和登录公告,活动数据,boos数据,以及封IP文件备份出来 更新完之后再还原
/bin/cp /data/web/minggame/www/chat/setting_system_cycle_msg.php /data/web/minggame/backup/
/bin/cp /data/web/minggame/www/cache/data/base_activities.php /data/web/minggame/backup/
/bin/cp /data/web/minggame/www/cache/data/base_boss.php /data/web/minggame/backup/
/bin/cp /data/web/minggame/www/cache/data/base_limit_ip.php /data/web/minggame/backup/

#3开始更新程序及检查版本
if /bin/bash /data/sh/update/mcsd/update_new_mcsd_version.sh ${GAMEFILE}
then
grep flex /data/web/minggame/www/version.php >> /data/logs/version_${UPDATE_DATE}.log 2>&1
fi

#4更新数据库及检查
if [ "${GAME_HOST}" = "A" ]
then
	if /bin/bash /data/sh/update/mcsd/update_db_mcsd.sh ${SQLFILE}
	then
		/bin/bash /data/sh/update/mcsd/update_db_mcsd.sh >> /data/logs/version_${UPDATE_DATE}.log 2>&1
	fi
	else echo "Slave server,there is no need to update DB." >> /data/logs/version_${UPDATE_DATE}.log 2>&1
fi

#5 还原代理设置的循环消息,活动数据,boos数据,以及封IP文件
/bin/cp /data/web/minggame/backup/setting_system_cycle_msg.php /data/web/minggame/www/chat/
/bin/cp /data/web/minggame/backup/base_activities.php /data/web/minggame/www/cache/data/
/bin/cp /data/web/minggame/backup/base_boss.php /data/web/minggame/www/cache/data/
/bin/cp /data/web/minggame/backup/base_limit_ip.php /data/web/minggame/www/cache/data/

#6清理tpl_compile目录里的文件
if cd /data/web/minggame/www/cache/tpl_compile/
then
rm -f *
fi

#7开启游戏
/bin/bash /data/sh/update/mcsd/stop_or_start_programme.sh start

#8因为代理没有关入口，所以暂时不要自动开放入口
#/bin/bash /data/sh/update/mcsd/open_or_close_entry.sh open