#!/bin/bash
#更新数据库的脚本，把sql文件scp到/data/web/minggame/，然后在远程执行此脚本即可
#所有代理都一样，不用因4399数据库名特殊而特殊处理了。
#                                     johncan 2009-12-29

UPDATE_DATE=`date +%Y%m%d%H%M`

MYSQL_BIN="/usr/local/bin/mysql"

DB_PASSWORD=`cat /data/save/mysql_root`

DB_NAME=`awk -F\' '/dbname/{print $4}' /data/web/minggame/config/config.inc.php |uniq`

UPDATE_SQL_FILE="$1"
PASSWD=`cat /data/save/mysql_root`
cd /data/web/minggame/

if [ ! -e "${UPDATE_SQL_FILE}" ] ; then
        #echo "${UPDATE_SQL_FILE} file not exist."
        mysql -uroot -p${PASSWD} ${DB_NAME} -s -e "select * from tversion"
        exit 1
fi

${MYSQL_BIN} -uroot -p"${DB_PASSWORD}" ${DB_NAME} < ${UPDATE_SQL_FILE}

/bin/mv ${UPDATE_SQL_FILE} backup/${UPDATE_SQL_FILE}.${UPDATE_DATE}
