#!/bin/bash
# Author johncan

if [ "${1}" = "open" ]
then
    sed -i "s/true/false/" /data/web/minggame/www/stop.php
else 
    sed -i "s/false/true/" /data/web/minggame/www/stop.php
fi	    
