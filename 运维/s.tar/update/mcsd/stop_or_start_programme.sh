#!/bin/bash
# Stop programme before update 
# Start programme after update
# Author johncan

if [ "$1" = "" ]; then
        echo "usage: $0 [start] [stop]"
        exit
fi

GAME_HOST=`awk -F[" "_] '/PS/ {print $5}' /root/.bashrc`

if [ "${1}" = "stop" ]
then
     pkill -9 nginx
     pkill -9 php-cgi   
     /root/memcached_stop
     pkill -9 memcache
     /root/mq_stop
     /bin/rm -rf /data/memcacheq/*
     pkill epmd
     pkill beam.smp
     pkill while
     service crond stop
	 sleep 60
   elif [ \( "${1}" = "start" \) -a \( "${GAME_HOST}" = "A" \) ]
    then
        /root/memcached_start
        /root/fastcgi_start
	/root/fastcgi_restart
        /root/nginx_start
	/root/nginx_reload
        /root/mq_start
        /root/ejabberdctl start
	pkill while
        service crond start
        sed -i "s/false/true/" /data/web/minggame/www/stop.php
	else 
        /root/fastcgi_start
	/root/fastcgi_restart
        /root/nginx_start
	/root/nginx_reload
        /root/ejabberdctl start
        pkill while
        service crond start
        sed -i "s/false/true/" /data/web/minggame/www/stop.php		
fi	
