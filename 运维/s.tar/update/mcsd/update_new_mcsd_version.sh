#!/bin/bash
#--------------------------------------------------
#更新明朝时代游戏服版本(新版本明朝目录结构)
#                               By:odinxu.20090818
#--------------------------------------------------

UPDATEFILE="$1"

#由于网络的不稳定因素所以不采取这种方式下载：）
cd /data/web/minggame/
#wget http://mm.xunwan.com/${UPDATEFILE}.tar.bz2

#关闭游戏入口
#pkill nginx
#pkill -9 php-cgi
#pkill -9 php-cgi
#/root/memcached_stop

if [ ! -e "${UPDATEFILE}" ] ; then
	echo "${UPDATEFILE} file not exist."	
	exit 1
fi

#开始顺序化操作
cd /data/web/minggame/
mkdir -p backup
TTT=`date +"%Y%m%d%H%M%S"`
/bin/cp -Rf config www/
/bin/mv www/ www.${TTT}
/bin/mv www.${TTT}/ backup/

tar xjf ${UPDATEFILE}
sh/make.sh

/bin/mv  ${UPDATEFILE}  backup/


