#!/bin/sh
#echo "LogLevel  DEBUG" >> /etc/ssh/sshd_config
#service sshd restart
get_key() {
cat /root/.ssh/authorized_keys | while read LINE
do
        if [ "$LINE" != "" ];then
                NAME=$(echo $LINE | awk '{print $3}')
                echo $LINE > /tmp/key.log
                MD5S=$(ssh-keygen -l -f /tmp/key.log)
                KEY=$(echo $MD5S | awk '{print $2}' )

                echo "$KEY $NAME"
                #cat /var/log/secure | grep "$KEY" |awk '{ print $1,$2,$3 }'
                #CON=$(cat /var/log/secure | grep "$KEY" |awk '{ print $1,$2,$3}')
                #echo ""
        fi
done
#exit
}
get_key > /tmp/tmpkey
AA=`cat /var/log/secure | grep "RSA key"|awk '{ print $1,$2,$3,$10 }'`
echo "$AA" > log
cat log|while read LINE
do
GG=`echo "$LINE"|awk '{print $4}'`
TT=`echo "$LINE"|awk '{print $1,$2,$3}'`
NAME=`cat /tmp/tmpkey|grep "$GG"|awk '{ print $2 }'`
echo "$TT" "$NAME"
done


