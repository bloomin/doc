#!/bin/bash
export PATH=/usr/kerberos/sbin:/usr/kerberos/bin:/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/usr/X11R6/bin:/root/bin

cd /data/web/minggame/config
DBNAME=`php show.php type=dbname`

if [ "${DBNAME}" = "" ]; then
        echo "DB name Error!"
        exit 1
else
	if [ ! -d "/data/database/mysql/${DBNAME}" ]; then
	        echo "DB name Error!"
	        exit 1	
	fi
fi

SID=`php show.php type=sid`
GAMESERVER="s${SID}"


INNOBACKUPEX="/usr/bin/innobackupex-1.5.1"


PREVDIR=`date -d -24hour +%Y%m%d`
PREVTIME=`date -d -24hour +%Y%m%d_%H`

CURTIME=`date +%Y%m%d_%H`
CURHOUR=`date +%H`

if [ $CURHOUR = 00 ]
then
	sleep 5400
fi

if [ $CURHOUR = 12 ]
then
	sleep 3600
fi

if [ $CURHOUR = 20 ]
then
	echo "It's time for Nation War!"
	exit
fi

DDIR=/data/backup/minggame/${GAMESERVER}/db/`date +%Y%m%d`
mkdir -p ${DDIR}


  FD=${DDIR}/${DBNAME}_${CURTIME}

  chown -R mysql:mysql ${DDIR}

    cd ${DDIR}
    /bin/rm ${DBNAME}_${CURTIME}.tar.gz
${INNOBACKUPEX} --user=root --password='`cat /data/save/mysql_root`' --no-lock --databases=${DBNAME} --stream=tar /tmp/ | /bin/gzip  > ${DBNAME}_${CURTIME}.tar.gz

  # delete old backup data file


if [ \( "${CURHOUR}" = "04" \) -o \( "${CURHOUR}" = "08" \) -o \( "${CURHOUR}" = "12" \) -o \( "${CURHOUR}" = "16" \) ]
then
  cd ${DDIR}
  cd ..
  /bin/rm -f ${PREVDIR}/${DBNAME}_${PREVTIME}.tar.gz
fi



# delete tooo old backup

cd ${DDIR}
cd ..
/bin/rm -rf `date -d -7day +"%Y%m%d"`
