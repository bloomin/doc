#!/bin/bash
#check fastcgi status,if there is error,restart fastcgi.
#Author johncan 2010-04-15.

GAME_HOST=`awk -F[" "_] '/PS/ {print $5}' /root/.bashrc`

#The domain and port of master is different from slave.
if [ "${GAME_HOST}" = "A" ]
then
	GAME_DOMAIN=`awk -F\" '/WEB_DOMAIN/ {print $4}' /data/web/minggame/config/config.inc.php |grep -v http`
	GAME_PORT=80
else 
	GAME_DOMAIN=localhost
	GAME_PORT=81
fi

#check fastcgi status with "curl",set time-out is 5 seconds.
if /usr/bin/curl -m 5 http://${GAME_DOMAIN}:${GAME_PORT}/admin/login.php | grep Gateway
then 
	/root/fastcgi_restart
else 
	echo "OK."
fi
