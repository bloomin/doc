#!/bin/bash

cd /data/web/minggame/config
AGENT=`php show.php type=agent`
SID=`php show.php type=sid`
GAMESERVER="s${SID}"


FD="/data/web/minggame/backup/"
mkdir -p ${FD}

cd /data/web/minggame
FN=minggame_${AGENT}_${GAMESERVER}_web_`date +"%Y%m%d%H%M"`.tar.bz2

tar -cjf ${FD}/${FN}  --exclude='*.log' www/ config/ sh/ 

cd ${FD} 
/bin/rm minggame_${AGENT}_${GAMESERVER}_web_`date -d -5day +"%Y%m%d"`*

