#!/bin/bash


cd /data/web/minggame/config
DBNAME=`php show.php type=dbname`

if [ "${DBNAME}" = "" ]; then
        echo "DB name Error!"
        exit 1
else
	if [ ! -d "/data/database/mysql/${DBNAME}" ]; then
	        echo "DB name Error!"
	        exit 1	
	fi
fi

SID=`php show.php type=sid`
GAMESERVER="s${SID}"


MYSQLPASSWORD=`cat /data/save/mysql_root`
MYSQLDUMP="/usr/local/mysql/bin/mysqldump"


PREVDIR=`date -d -24hour +%Y%m%d`
PREVTIME=`date -d -24hour +%Y%m%d_%H`

CURTIME=`date +%Y%m%d_%H`
CURHOUR=`date +%H`
DDIR=/data/backup/minggame/${GAMESERVER}/db/`date +%Y%m%d`
mkdir -p ${DDIR}


  FD=${DDIR}/${DBNAME}_${CURTIME}
  mkdir -p ${FD}

  chown -R mysql:mysql ${DDIR}
  cd ${FD}

  # export db struct
  ${MYSQLDUMP} -uroot -p${MYSQLPASSWORD} -d ${DBNAME} > ${FD}/db_struc.sql

  # export txt data, only HOUR = 4 , run full backup
  if [ "${CURHOUR}" = "04" ]
  then
    ${MYSQLDUMP} -uroot -p${MYSQLPASSWORD} -T${FD}  ${DBNAME}
  else
    ${MYSQLDUMP} -uroot -p${MYSQLPASSWORD} --ignore-table=${DBNAME}.tmsg_war_log --ignore-table=${DBNAME}.tmsg_war --ignore-table=${DBNAME}.tlog_login  -T${FD}  ${DBNAME}
  fi


  # compress file only HOUR = 4 OR 6
  if [ \( "${CURHOUR}" = "04" \) -o \( "${CURHOUR}" = "06" \) ]
  then
    cd ${DDIR}
    /bin/rm ${DBNAME}_${CURTIME}.tar.bz2
    tar cjf ${DBNAME}_${CURTIME}.tar.bz2  ${DBNAME}_${CURTIME}
  fi

  # delete old backup data dir
  cd ${DDIR}
  cd ..
  /bin/rm -rf ${PREVDIR}/${DBNAME}_${PREVTIME}



# delete tooo old backup
cd ${DDIR}
cd ..
/bin/rm -rf `date -d -7day +"%Y%m%d"`


