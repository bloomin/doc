#!/bin/bash

FD=/data/logs/log`date +"%Y%m%d%H%M"`
mkdir -p ${FD}

cd ${FD}
cd ..
mv *.log ${FD}/
/root/nginx_reload

OLDFD="log"`date -d -5day +"%Y%m%d"`"*"
cd /data/logs
/bin/rm -rf ${OLDFD}

