#!/bin/bash
if ! ps aux |grep ntp |grep -v grep
then 
service ntpd start
hwclock --systohc
fi
