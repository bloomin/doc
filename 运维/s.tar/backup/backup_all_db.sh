#!/bin/bash

MATRIX="123456789"
LENGTH="3"
while [ "${n:=1}" -le "$LENGTH" ]
do
        SLEEP_TIME="$SLEEP_TIME${MATRIX:$(($RANDOM%${#MATRIX})):1}"
        let n+=1
done

sleep $SLEEP_TIME

get_curr_time() {
        echo `date +"%Y-%m-%d %H:%M:%S"`
}

get_curr_day() {
        echo `date +"%Y-%m-%d"`
}

get_yesterday() {
        #echo `date -v-1d +"%Y-%m-%d"`
        echo `date -d yesterday +"%Y-%m-%d"`
}

copy_database() {
	dbname="$1"
	bzfile="/data/backup/database/${dbname}/${dbname}_"`get_curr_day`".tar.bz2"
	echo ${bzfile}

	mkdir -p "$2"
	cp "${bzfile}" "$2"

	#remove old backup directory
    oldbackupdir="/data/backup/database/${dbname}/"`get_yesterday`
	if [ -d "${oldbackupdir}" ]
	then
		rm -rf "${oldbackupdir}"
	fi
}

remove_old_db() {
        dbname="$1"

        #remove old backup directory
        oldbackupdir="/data/backup/database/${dbname}/"`get_yesterday`
        if [ -d "${oldbackupdir}" ]
        then
                rm -rf "${oldbackupdir}"
        fi
}


cd /data/web/minggame/config
DBNAME=`php show.php type=dbname`

if [ "${DBNAME}" = "" ]; then
        echo "DB name Error!"
        exit 1
else
        if [ ! -d "/data/database/mysql/${DBNAME}" ]; then
                echo "DB name Error!"
                exit 1
        fi
fi

cd /data/sh/backup

./backup_database.sh ${DBNAME}

remove_old_db ${DBNAME}

#./backup_database.sh carschina_bbs

#copy_database  carschina_bbs /data/web/carschina.com/db/

