#!/bin/bash

# backup database, written by odinxu.  2007-10-09

show_help() {
        echo "Usage:"
        echo "$0 <database name>"
        exit 1
}


get_curr_time() {
        echo `date +"%Y-%m-%d %H:%M:%S"`
}

get_curr_day() {
        echo `date +"%Y-%m-%d"`
}

save_log() {
        echo "" >> ${LOGFILE}
        echo "Time: "`get_curr_time`"   $1 " >> ${LOGFILE}
}

if [ $# -ne 1 ]
then
	show_help
fi

DATABASENAME="$1"
ORIGDIR="/data/backup/database"
MYSQLPASSWORD=`cat /data/save/mysql_root`

MYSQLDUMP="/usr/local/bin/mysqldump"
TAR="/usr/bin/tar"

CURRDAY=`get_curr_day`
BACKUPPARENTDIR="${ORIGDIR}/${DATABASENAME}"
BACKUPDIR="${BACKUPPARENTDIR}/${CURRDAY}"
BACKUPFILENAME="${BACKUPPARENTDIR}/${DATABASENAME}_${CURRDAY}.tar.bz2"

LOGFILE="${ORIGDIR}/backup_database.log"
echo "" >> ${LOGFILE}
echo "=======================================================================" >> ${LOGFILE}

# Ŀ¼���ļ��Ѿ����ڣ�������˳�
if [ -d "${BACKUPDIR}" ]
then
	echo "${BACKUPDIR} directory had exist! "
	save_log "${BACKUPDIR} directory had exist! "
	exit 1
fi
if [ -e "${BACKUPFILENAME}" ]
then
	echo "${BACKUPFILENAME} file had exist! "
	save_log "${BACKUPFILENAME} file had exist! "
	exit 1
fi

# ȷ��Ŀ¼�ṹ��Ŀ¼Ȩ��(����mysql�û���Ȩ�޶�д)
mkdir -p ${BACKUPDIR}
chown mysql:mysql "${BACKUPPARENTDIR}"
chmod 770 "${BACKUPPARENTDIR}"
chown mysql:mysql ${BACKUPDIR}
chmod 770 ${BACKUPDIR}

cd ${BACKUPPARENTDIR}

# ֻ�����������ݿ�ṹ������������
save_log "Start dump ${DATABASENAME} structure to ${BACKUPDIR}/${DATABASENAME}_db_struc.sql"
${MYSQLDUMP} -uroot -p${MYSQLPASSWORD} -d ${DATABASENAME} > "${BACKUPDIR}/${DATABASENAME}_db_struc.sql"

# �� txt �ļ��ķ�ʽ�ֱ���������
save_log "Start dump ${DATABASENAME} all data to DIR ${BACKUPDIR}"
${MYSQLDUMP} -uroot -p${MYSQLPASSWORD} --single-transaction -T${BACKUPDIR}  ${DATABASENAME}

# �������������
save_log "Start compress to ${BACKUPFILENAME}"
cd ${BACKUPPARENTDIR}
${TAR} cjvf ${BACKUPFILENAME} ${CURRDAY}

# ��ɲ���
save_log "BACKUP DATABASE ${DATABASENAME} SUCCEED"



