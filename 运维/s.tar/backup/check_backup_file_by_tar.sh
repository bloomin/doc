#!/bin/bash
#check database's backup
#

CHECK_DATE=`date -d -1day +%Y-%m-%d`
DB_NAME=`awk -F\' '/dbname/{print $4}' /data/web/minggame/config/config.inc.php |uniq`

cd /tmp
/bin/rm -rf ${CHECK_DATE}
if tar xjf /data/backup/database/${DB_NAME}/${DB_NAME}_${CHECK_DATE}.tar.bz2
then
	echo "${DB_NAME}_${CHECK_DATE}.tar.bz2 is OK." >> /data/logs/check_backup_file_by_tar.log
else
    echo "Error.${DB_NAME}_${CHECK_DATE}.tar.bz2 is not OK." >> /data/logs/check_backup_file_by_tar.log
fi
	
/bin/rm -rf ${CHECK_DATE}
