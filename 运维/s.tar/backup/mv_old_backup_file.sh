#!/bin/bash

cd /data/web/minggame/config
DB_NAME=`/usr/bin/php show.php type=dbname`


mkdir /data/backup/database/OLD_backup_file/

find /data/backup/database/${DB_NAME} -type f -mtime +15 | \
while read file
do
mv $file /data/backup/database/OLD_backup_file/
done

find /data/backup/database/OLD_backup_file/ -type f -mtime +60 | xargs -r /bin/rm
